This Model was created by Lt1 and Black Rayne Studios.

--------------------------------------------------------------
if  you need anything made or this object modified or skinned differently please let me 
know and it will be done. feel free to contact me at:
 
---------------------------------blackraynestudios@gmail.com---------------------------

also there is a forum on my website for suggestions and requests
---------------------------------------------------------------------------------------
http://www.blackrayne.net

Copyrights :
  This game component is created and owned by Lt1 and Black rayne Studios.
  No modifications on any part of it are allowed unless indicated.
  You may not use this object as base to create another one. It must be used
  as is. You can use it freely in any games as long as you include a note
  indicating you got it from me. For any troubleshooting or inquiry, feel free
  to contact me.
